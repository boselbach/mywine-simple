# Mywine simple

## Install
> npm install

## Run project
> npm run start

## See project
> Navigato to http://localhost:3000